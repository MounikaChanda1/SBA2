package com.iiht.training.eloan.service.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.eloan.dto.LoanDto;
import com.iiht.training.eloan.dto.LoanOutputDto;
import com.iiht.training.eloan.dto.ProcessingDto;
import com.iiht.training.eloan.dto.RejectDto;
import com.iiht.training.eloan.dto.SanctionOutputDto;
import com.iiht.training.eloan.dto.UserDto;
import com.iiht.training.eloan.entity.Loan;
import com.iiht.training.eloan.entity.ProcessingInfo;
import com.iiht.training.eloan.entity.SanctionInfo;
import com.iiht.training.eloan.entity.Users;
import com.iiht.training.eloan.exception.CustomerNotFoundException;
import com.iiht.training.eloan.exception.LoanNotFoundException;
import com.iiht.training.eloan.repository.LoanRepository;
import com.iiht.training.eloan.repository.ProcessingInfoRepository;
import com.iiht.training.eloan.repository.SanctionInfoRepository;
import com.iiht.training.eloan.repository.UsersRepository;
import com.iiht.training.eloan.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private UsersRepository usersRepository;

	@Autowired
	private LoanRepository loanRepository;

	@Autowired
	private ProcessingInfoRepository processingInfoRepository;

	@Autowired
	private SanctionInfoRepository sanctionInfoRepository;

	// Utility method for Customer registration
	private UserDto convertUserEntityToUserDto(Users newUser) {
		UserDto userDto = new UserDto();
		userDto.setId(newUser.getId());
		userDto.setFirstName(newUser.getFirstName());
		userDto.setLastName(newUser.getLastName());
		userDto.setEmail(newUser.getEmail());
		userDto.setMobile(newUser.getMobile());
		return userDto;
	}

	private Users convertUserDtoToUserEntity(UserDto userDto) {
		Users user = new Users();
		user.setFirstName(userDto.getFirstName());
		user.setLastName(userDto.getLastName());
		user.setEmail(userDto.getEmail());
		user.setMobile(userDto.getMobile());
		return user;
	}

	// Utility method for Applying loan
	private LoanOutputDto convertLoanEntityToLoanOutputDto(UserDto newUserDto, LoanDto loanDto) {
		LoanOutputDto loanOutputDto = new LoanOutputDto();
		loanOutputDto.setCustomerId(newUserDto.getId());
		loanOutputDto.setLoanDto(loanDto);
		loanOutputDto.setUserDto(newUserDto);
		loanOutputDto.setStatus("Applied");
		return loanOutputDto;
	}
	
	private Loan convertLoanDtoToLoanEntity(Long customerId,LoanDto loanDto) {
		Loan loan = new Loan();
		loan.setLoanName(loanDto.getLoanName());
		loan.setLoanAmount(loanDto.getLoanAmount());
		loan.setBillingIndicator(loanDto.getBillingIndicator());
		loan.setBusinessStructure(loanDto.getBusinessStructure());
		loan.setLoanApplicationDate(loanDto.getLoanApplicationDate());
	    loan.setTaxIndicator(loanDto.getTaxIndicator());
		return loan;
	}

	private LoanDto convertLoanEntityToLoanDto(Loan loan) {
		LoanDto loanDto = new LoanDto();
		loanDto.setLoanName(loan.getLoanName());
		loanDto.setLoanAmount(loan.getLoanAmount());
		loanDto.setBillingIndicator(loan.getBillingIndicator());
		loanDto.setBusinessStructure(loan.getBusinessStructure());
		loanDto.setLoanApplicationDate(loan.getLoanApplicationDate());
		loanDto.setTaxIndicator(loan.getTaxIndicator());
		return loanDto;
	}
	
	
	private ProcessingDto convertProcessEntityToProcessingDto(ProcessingInfo processingInfo) {
		ProcessingDto ProcessingDto = new ProcessingDto();
		ProcessingDto.setAcresOfLand(processingInfo.getAcresOfLand());
		ProcessingDto.setAddressOfProperty(processingInfo.getAddressOfProperty());
		ProcessingDto.setAppraisedBy(processingInfo.getAppraisedBy());
		ProcessingDto.setLandValue(processingInfo.getLandValue());
		ProcessingDto.setSuggestedAmountOfLoan(processingInfo.getSuggestedAmountOfLoan());
		ProcessingDto.setValuationDate(processingInfo.getValuationDate());
		return ProcessingDto;
	}

	private SanctionOutputDto convertSanctionEntityToSanctionOutputDto(SanctionInfo sanctionInfo) {
		SanctionOutputDto SanctionOutputDto = new SanctionOutputDto();
		SanctionOutputDto.setLoanAmountSanctioned(sanctionInfo.getLoanAmountSanctioned());
		SanctionOutputDto.setLoanClosureDate(sanctionInfo.getLoanClosureDate());
		SanctionOutputDto.setMonthlyPayment(sanctionInfo.getMonthlyPayment());
		SanctionOutputDto.setPaymentStartDate(sanctionInfo.getPaymentStartDate());
		SanctionOutputDto.setTermOfLoan(sanctionInfo.getTermOfLoan());
		return SanctionOutputDto;
	}

	//Utility method for Status of loan

	private LoanOutputDto ConvertLoanEntitytoLoanStatusOutputDto(Loan loan) {
		Long CustomerId = loan.getCustomerId();
		Long loanAppId = loan.getId();
		Users user = this.usersRepository.findById(CustomerId).orElse(null);
		String Remarks=loan.getRemark();
		SanctionInfo SanctionInfo = this.sanctionInfoRepository.findByloanAppId(loanAppId);
		ProcessingInfo ProcessingInfo = this.processingInfoRepository.findByloanAppId(loanAppId);
		LoanOutputDto loanOutputDto = new LoanOutputDto();
		loanOutputDto.setCustomerId(loan.getCustomerId());
		loanOutputDto.setLoanAppId(loan.getId());
		LoanDto loanDto = this.convertLoanEntityToLoanDto(loan);
		UserDto userDto = this.convertUserEntityToUserDto(user);
		loanOutputDto.setLoanDto(loanDto);
		loanOutputDto.setUserDto(userDto);
		if (loan.getStatus() == 0) {
			loanOutputDto.setStatus("Applied");
			return loanOutputDto;
		} else if (loan.getStatus() == 1) {
			loanOutputDto.setStatus("Processed");
			ProcessingDto ProcessingDto = this.convertProcessEntityToProcessingDto(ProcessingInfo);
			loanOutputDto.setProcessingDto(ProcessingDto);
			return loanOutputDto;
		} else if (loan.getStatus() == 2) {
			loanOutputDto.setStatus("Sanctioned");
			ProcessingDto ProcessingDto = this.convertProcessEntityToProcessingDto(ProcessingInfo);
			loanOutputDto.setProcessingDto(ProcessingDto);
			SanctionOutputDto SanctionOutputDto = this.convertSanctionEntityToSanctionOutputDto(SanctionInfo);
			loanOutputDto.setSanctionOutputDto(SanctionOutputDto);
			return loanOutputDto;
		} else if (loan.getStatus() == -1)
			loanOutputDto.setStatus("Rejected");
		ProcessingDto ProcessingDto = this.convertProcessEntityToProcessingDto(ProcessingInfo);
		loanOutputDto.setProcessingDto(ProcessingDto);
		loanOutputDto.setRemark(Remarks);
		return loanOutputDto;
	}

	
	
	
	@Override
	public UserDto register(UserDto userDto) {
		Users user = this.convertUserDtoToUserEntity(userDto);
		user.setRole("Customer");
		Users newUser = this.usersRepository.save(user);
		UserDto newUserDto = this.convertUserEntityToUserDto(newUser);
		return newUserDto;

	}

	@Override
	public LoanOutputDto applyLoan(Long customerId, LoanDto loanDto) {
		Users user = this.usersRepository.findById(customerId).orElse(null);
		if(user ==null)
			throw new CustomerNotFoundException("No CustomerId found");
		String role = user.getRole();
		if (this.usersRepository.existsById(customerId) && role.equals("Customer")) {
			Loan loan = this.convertLoanDtoToLoanEntity(customerId,loanDto);
			loan.setCustomerId(customerId);
			loan.setStatus(0);
			Loan newLoan = this.loanRepository.save(loan);
			loanDto.setLoanApplicationDate(newLoan.getLoanApplicationDate());
			Long loanAppId = newLoan.getId();
			UserDto newUserDto = this.convertUserEntityToUserDto(user);
			LoanOutputDto loanOutputDto = this.convertLoanEntityToLoanOutputDto(newUserDto, loanDto);
			loanOutputDto.setLoanAppId(loanAppId);
			return loanOutputDto;
		}
		return null;
	}

	@Override
	public LoanOutputDto getStatus(Long loanAppId) {
		Loan Loan = this.loanRepository.findById(loanAppId).orElse(null);
		LoanOutputDto loanOutputDto = this.ConvertLoanEntitytoLoanStatusOutputDto(Loan);
		return loanOutputDto;
	}

	@Override
	public List<LoanOutputDto> getStatusAll(Long customerId) {
		List<Loan> listloans = this.loanRepository.findByCustomerId(customerId);
		List<LoanOutputDto> loanOutputDto = listloans.stream().map(this::ConvertLoanEntitytoLoanStatusOutputDto)
				.collect(Collectors.toList());

		return loanOutputDto;
	}



}
