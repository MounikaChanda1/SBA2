package com.iiht.training.eloan.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.eloan.dto.LoanDto;
import com.iiht.training.eloan.dto.LoanOutputDto;
import com.iiht.training.eloan.dto.ProcessingDto;
import com.iiht.training.eloan.dto.RejectDto;
import com.iiht.training.eloan.dto.SanctionDto;
import com.iiht.training.eloan.dto.SanctionOutputDto;
import com.iiht.training.eloan.dto.UserDto;
import com.iiht.training.eloan.entity.Loan;
import com.iiht.training.eloan.entity.ProcessingInfo;
import com.iiht.training.eloan.entity.SanctionInfo;
import com.iiht.training.eloan.entity.Users;
import com.iiht.training.eloan.exception.AlreadyFinalizedException;
import com.iiht.training.eloan.exception.CustomerNotFoundException;
import com.iiht.training.eloan.exception.LoanNotFoundException;
import com.iiht.training.eloan.exception.ManagerNotFoundException;
import com.iiht.training.eloan.repository.LoanRepository;
import com.iiht.training.eloan.repository.ProcessingInfoRepository;
import com.iiht.training.eloan.repository.SanctionInfoRepository;
import com.iiht.training.eloan.repository.UsersRepository;
import com.iiht.training.eloan.service.ManagerService;

@Service
public class ManagerServiceImpl implements ManagerService {

	@Autowired
	private UsersRepository usersRepository;

	@Autowired
	private LoanRepository loanRepository;

	@Autowired
	private ProcessingInfoRepository processingInfoRepository;

	@Autowired
	private SanctionInfoRepository sanctionInfoRepository;

	//Utility methods
	
	private SanctionInfo convertSanctionDtoToSanctionEntity(SanctionDto sanctionDto) {
		SanctionInfo sanctionInfo = new SanctionInfo();
		sanctionInfo.setLoanAmountSanctioned(sanctionDto.getLoanAmountSanctioned());
		Double LoanAmountSanctioned = sanctionDto.getLoanAmountSanctioned();
		sanctionInfo.setPaymentStartDate(sanctionDto.getPaymentStartDate());
		String PaymentStartDate = sanctionDto.getPaymentStartDate();
		sanctionInfo.setTermOfLoan(sanctionDto.getTermOfLoan());
		double TermOfLoan = sanctionDto.getTermOfLoan();
			double Termpaymentamount = (LoanAmountSanctioned) * Math.pow((1 + 4.5 / 100), TermOfLoan);
			Double Monthlypayment = Termpaymentamount / TermOfLoan;
			sanctionInfo.setMonthlyPayment(Monthlypayment);
			return sanctionInfo;
	}

	private UserDto convertUserEntityToUserDto(Users NewUser) {
		UserDto userDto = new UserDto();
		userDto.setId(NewUser.getId());
		userDto.setFirstName(NewUser.getFirstName());
		userDto.setLastName(NewUser.getLastName());
		userDto.setEmail(NewUser.getEmail());
		userDto.setMobile(NewUser.getMobile());
		return userDto;
	}

	private ProcessingDto convertProcessEntityToProcessingDto(ProcessingInfo processingInfo) {
		ProcessingDto ProcessingDto = new ProcessingDto();
		ProcessingDto.setAcresOfLand(processingInfo.getAcresOfLand());
		ProcessingDto.setAddressOfProperty(processingInfo.getAddressOfProperty());
		ProcessingDto.setAppraisedBy(processingInfo.getAppraisedBy());
		ProcessingDto.setLandValue(processingInfo.getLandValue());
		ProcessingDto.setSuggestedAmountOfLoan(processingInfo.getSuggestedAmountOfLoan());
		ProcessingDto.setValuationDate(processingInfo.getValuationDate());
		return ProcessingDto;
	}

	private SanctionOutputDto convertSanctionEntityToSanctionOutputDto(SanctionInfo sanctionInfo) {
		SanctionOutputDto SanctionOutputDto = new SanctionOutputDto();
		SanctionOutputDto.setLoanAmountSanctioned(sanctionInfo.getLoanAmountSanctioned());
		SanctionOutputDto.setLoanClosureDate(sanctionInfo.getLoanClosureDate());
		SanctionOutputDto.setMonthlyPayment(sanctionInfo.getMonthlyPayment());
		SanctionOutputDto.setPaymentStartDate(sanctionInfo.getPaymentStartDate());
		SanctionOutputDto.setTermOfLoan(sanctionInfo.getTermOfLoan());
		return SanctionOutputDto;
	}

	private LoanOutputDto ConvertLoanEntitytoLoanStatusOutputDto(Loan loan) {
		Long CustomerId = loan.getCustomerId();
		Long loanAppId = loan.getId();
		Users user = this.usersRepository.findById(CustomerId).orElse(null);
		SanctionInfo SanctionInfo = this.sanctionInfoRepository.findByloanAppId(loanAppId);
		ProcessingInfo ProcessingInfo = this.processingInfoRepository.findByloanAppId(loanAppId);
		LoanOutputDto loanOutputDto = new LoanOutputDto();
		loanOutputDto.setCustomerId(loan.getCustomerId());
		loanOutputDto.setLoanAppId(loan.getId());
		LoanDto loanDto = this.convertLoanEntityToLoanDto(loan);
		UserDto userDto = this.convertUserEntityToUserDto(user);
		loanOutputDto.setLoanDto(loanDto);
		loanOutputDto.setUserDto(userDto);
		if (loan.getStatus() == 0) {
			loanOutputDto.setStatus("Applied");
			return loanOutputDto;
		} else if (loan.getStatus() == 1) {
			loanOutputDto.setStatus("Processed");
			ProcessingDto ProcessingDto = this.convertProcessEntityToProcessingDto(ProcessingInfo);
			loanOutputDto.setProcessingDto(ProcessingDto);
			return loanOutputDto;
		} else if (loan.getStatus() == 2) {
			loanOutputDto.setStatus("Sanctioned");
			ProcessingDto ProcessingDto = this.convertProcessEntityToProcessingDto(ProcessingInfo);
			loanOutputDto.setProcessingDto(ProcessingDto);
			SanctionOutputDto SanctionOutputDto = this.convertSanctionEntityToSanctionOutputDto(SanctionInfo);
			loanOutputDto.setSanctionOutputDto(SanctionOutputDto);
			return loanOutputDto;
		} else if (loan.getStatus() == -1)
			loanOutputDto.setStatus("Rejected");
		RejectDto RejectDto = new RejectDto();
		loanOutputDto.setRemark(RejectDto.getRemark());
		return loanOutputDto;
	}

	private LoanDto convertLoanEntityToLoanDto(Loan loan) {
		LoanDto loanDto = new LoanDto();
		loanDto.setBillingIndicator(loan.getBillingIndicator());
		loanDto.setBusinessStructure(loan.getBusinessStructure());
		loanDto.setLoanAmount(loan.getLoanAmount());
		loanDto.setLoanApplicationDate(loan.getLoanApplicationDate());
		loanDto.setLoanName(loan.getLoanName());
		loanDto.setTaxIndicator(loan.getTaxIndicator());
		return loanDto;
	}
	
	@Override
	public List<LoanOutputDto> allProcessedLoans() {
		List<Loan> loans = this.loanRepository.findByStatus(1);
		List<LoanOutputDto> loanOutputDto = loans.stream().map(this::ConvertLoanEntitytoLoanStatusOutputDto)
				.collect(Collectors.toList());
		return loanOutputDto;
	}

	@Override
	public RejectDto rejectLoan(Long managerId, Long loanAppId, RejectDto rejectDto) {
		Loan loan = this.loanRepository.findById(loanAppId).orElse(null);
		Users user = this.usersRepository.findById(managerId).orElse(null);
		String Role = user.getRole();
		if (Role.equals("Manager")) {
			int loanstatus = loan.getStatus();
			if (loanstatus == 1) {
				loan.setRemark(rejectDto.getRemark());
				loan.setStatus(-1);
				this.loanRepository.save(loan);
				return rejectDto;
			}

		}
		throw new AlreadyFinalizedException("Loan already completed");
	}

	@Override
	public SanctionOutputDto sanctionLoan(Long managerId, Long loanAppId, SanctionDto sanctionDto) {
		Users user = this.usersRepository.findById(managerId).orElse(null);
		Loan loan = this.loanRepository.findById(loanAppId).orElse(null);
		String Role = user.getRole();
		if (Role.equals("Manager")) {
			int loanstatus = loan.getStatus();
			if (loanstatus == 1) {
                SanctionInfo sanctionInfo = this.convertSanctionDtoToSanctionEntity(sanctionDto);
				sanctionInfo.setLoanAppId(loanAppId);
				sanctionInfo.setManagerId(managerId);
				SanctionInfo newsanctionInfo = this.sanctionInfoRepository.save(sanctionInfo);
				SanctionOutputDto sanctionOutputDto = this.convertSanctionEntityToSanctionOutputDto(newsanctionInfo);
				loan.setStatus(2);
				this.loanRepository.save(loan);
				return sanctionOutputDto;
			}
		}
		throw new AlreadyFinalizedException("Loan already completed");

	}



}
